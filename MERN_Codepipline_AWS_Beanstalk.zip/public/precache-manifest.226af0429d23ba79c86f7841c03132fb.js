self.__precacheManifest = [
  {
    "revision": "df605b640cd4ff74db55",
    "url": "/static/css/main.21b4eff9.chunk.css"
  },
  {
    "revision": "df605b640cd4ff74db55",
    "url": "/static/js/main.df605b64.chunk.js"
  },
  {
    "revision": "fdfcfda2d9b1bf31db52",
    "url": "/static/js/runtime~main.fdfcfda2.js"
  },
  {
    "revision": "d89d30a18f86bfad9aa0",
    "url": "/static/css/2.a28d7e68.chunk.css"
  },
  {
    "revision": "d89d30a18f86bfad9aa0",
    "url": "/static/js/2.d89d30a1.chunk.js"
  },
  {
    "revision": "5c8a7cdba4adec390f500c9e658ded3a",
    "url": "/index.html"
  }
];